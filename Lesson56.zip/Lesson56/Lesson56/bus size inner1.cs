﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson56
{
    public partial class bus_size_inner1 : Form
    {
        public bus_size_inner1()
        {
            InitializeComponent();
        }

        private void bus_size_inner1_Load(object sender, EventArgs e)
        {

        }
    }
}
