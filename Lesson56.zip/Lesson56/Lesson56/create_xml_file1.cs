﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Lesson56
{
    public partial class create_xml_file1 : Form
    {
        public create_xml_file1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.NewLineOnAttributes = false;
            XmlWriter writer = XmlWriter.Create("d:\\NE Library.xml", settings);//文件保存在了C:\Users\Administrator\Desktop\CSharpStudy\Lesson56\Lesson56\bin\Debug
            writer.WriteStartDocument();
            writer.WriteStartElement("Table");
 
 
            
                writer.WriteStartElement("row");
                writer.WriteAttributeString("Version", "1.0");
                writer.WriteAttributeString("sion", "2.0");//you can add a second property at here
                writer.WriteElementString("ID", "01");//this function can create the end automatically自动生成末尾
                writer.WriteElementString("BookName", "PID");
               
               
                writer.WriteElementString("Position", "row1");
                writer.WriteElementString("price", "10");
                writer.WriteEndElement();
         
 
 
            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Flush();
            writer.Close();


        }
    }
}
