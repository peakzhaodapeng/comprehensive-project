﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson56
{
    public partial class cslearn : Form
    {
        public cslearn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("http://www.cnblogs.com/eye-like/p/4121219.html");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://docs.microsoft.com/zh-cn/dotnet/api/microsoft.office.interop.word?view=word-pia");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.cnblogs.com/wuhailong/p/5632947.html");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://wenku.baidu.com/view/95ed9a410640be1e650e52ea551810a6f424c861.html");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("http://www.mamicode.com/info-detail-1552039.html");
        }

        private void button6_Click(object sender, EventArgs e)
        {

            webBrowser1.Navigate("https://www.cnblogs.com/shi2172843/p/5848116.html");
        }
    }
}
