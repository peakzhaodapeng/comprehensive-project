﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Lesson56
{
    public partial class curve_with_net : Form
    {
        public float startPoint_x = 20f;
        public float startPoint_y = 100f;
        public float endPoint_x = 520;
        public float width = 500;
        public float height = 300;
        public float firstLine_y = 150f;
        public float delta_y=50;
        public float t = 20;
        public curve_with_net()
        {
            InitializeComponent();
            //先画一个固定的网格，就是曲线的的坐标是定死的，但是曲线会动啊，所以可以让纵坐标不动让横坐标和采样点一起动。
            //我打算采用定时查询的方式
        }
        Queue myQ = new Queue();
        private void timer1_Tick(object sender, EventArgs e)
        {

            // Random r = new Random();
            //float i=r.Next(-30,30);
            Graphics g = this.CreateGraphics();
            //Rectangle rect = new Rectangle(this.ClientRectangle.Width / 2 - 80, this.ClientRectangle.Height / 2 - 80, 160, 160);
            Pen p = new Pen(Color.FromKnownColor(KnownColor.Black), 2);
            Pen p1 = new Pen(Color.FromKnownColor(KnownColor.Blue), 2);
            Pen p2 = new Pen(Color.FromKnownColor(KnownColor.White), 2);

            int data;

            data = serialPort1.ReadByte();


            textBox1.Text = data.ToString();
            if (myQ.Count <= 49)
            {
                //myQ.Enqueue(20 * Math.Sin(2 * Math.PI / 100 * t));
                myQ.Enqueue(data);
                // myQ.Enqueue(i);
            }
            else
            {
                // myQ.Enqueue(20 * Math.Sin(2 * Math.PI / 100 * t));
                myQ.Enqueue(data);
                // myQ.Enqueue(i);

                myQ.Dequeue();

            }
            object[] a1 = myQ.ToArray();
            t += 10f;
            this.Refresh();
            g.DrawRectangle(p, startPoint_x, startPoint_y, width, height);

            g.DrawLine(p2, startPoint_x, firstLine_y, endPoint_x, firstLine_y);
            g.DrawLine(p2, startPoint_x, firstLine_y + delta_y, endPoint_x, firstLine_y + delta_y);
            g.DrawLine(p2, startPoint_x, firstLine_y + delta_y * 2, endPoint_x, firstLine_y + delta_y * 2);
            g.DrawLine(p2, startPoint_x, firstLine_y + delta_y * 3, endPoint_x, firstLine_y + delta_y * 3);
            g.DrawLine(p2, startPoint_x, firstLine_y + delta_y * 4, endPoint_x, firstLine_y + delta_y * 4);
            float m = 20;
            for (int l = 0; l < a1.Length; l++)
            {
                //if (float.Parse(a1.GetValue(l).ToString()) > float.MaxValue || float.Parse(a1.GetValue(l).ToString()) < float.MinValue)
                //{
                //    serialPort1.DiscardInBuffer();
                //    g.DrawEllipse(p, m, 200, 10.0f, 10.0f);
                //}
                //else
                //{
                if (float.Parse(a1.GetValue(l).ToString()) > 1000 || float.Parse(a1.GetValue(l).ToString()) < -1000)
                {
                    serialPort1.DiscardOutBuffer();
                    serialPort1.DiscardInBuffer();
                }
                if (a1.GetValue(l).ToString() == "")
                {
                    g.DrawEllipse(p1, m, 0f + 250, 10.0f, 10.0f);

                }
                else
                {
                    g.DrawEllipse(p1, m, float.Parse(a1.GetValue(l).ToString()) + 200, 5.0f, 5.0f);

                }

                // }
                // g.DrawEllipse(pen, m, float.Parse(a3.GetValue(l).ToString()) + 500, 10.0f, 10.0f);
                g.DrawLine(p2, m, startPoint_y, m, startPoint_y + height);

                m += 10;

            }
        }

        private void curve_with_net_Load(object sender, EventArgs e)
        {
            serialPort1.PortName = "COM6";
            serialPort1.BaudRate = 9600;
            serialPort1.Open();
            Graphics g = this.CreateGraphics();
           // Rectangle rect = new Rectangle(this.ClientRectangle.Width / 2 - 80, this.ClientRectangle.Height / 2 - 80, 160, 160);
            Pen p = new Pen(Color.FromKnownColor(KnownColor.Black), 2);
            Pen p1 = new Pen(Color.FromKnownColor(KnownColor.Blue), 2);
            Pen p2 = new Pen(Color.FromKnownColor(KnownColor.White), 2);
            g.DrawRectangle(p, startPoint_x, startPoint_y, width, height);

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

    }
}
