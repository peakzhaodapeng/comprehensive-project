﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson56
{
    public partial class del1 : Form
    {
        delegate void a();//declare a delegate
        class b
        {
                public void c()//this is an instance method
                {
                MessageBox.Show("this is the 1st method");
                }
                public void e()//this is another instance method
                {
                    MessageBox.Show("this is an instance method");
                }
                static public void d()//this is a static method
                {
                MessageBox.Show("2nd method");
                }
                
        }
        public del1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        b bexample=new b();
        a delexample = bexample.c;//map the delegate to instance method
        delexample();
        delexample = bexample.e;//
        delexample();
        delexample = b.d;//map the delegate to the static 
        delexample();
 

        }
    }
}
