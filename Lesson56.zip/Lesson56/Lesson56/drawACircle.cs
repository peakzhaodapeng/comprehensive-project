﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Lesson56
{
    public partial class drawACircle : Form
    {
        public drawACircle()
        {
            InitializeComponent();
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Brush b = new SolidBrush(Color.Blue);
            Rectangle rect = new Rectangle(this.ClientRectangle.Width / 2 - 80, this.ClientRectangle.Height / 2 - 80, 160, 160);
            Pen p = new Pen(Color.FromKnownColor(KnownColor.Chocolate), 20);
            g.DrawEllipse(p, rect);
            Pen pen = new Pen(Color.FromArgb(255, 0, 0, 0), 400);
            g.DrawLine(pen, 20, 10, 20, 11);
            Bitmap bmp = new Bitmap("C:\\Users\\Administrator\\Desktop\\CSharpStudy\\Lesson56\\Lesson56\\timg.gif");
            Brush tb = new TextureBrush(bmp);
            Pen pen2 = new Pen(tb, 50);
            g.DrawLine(pen2, 20, 90, 1000, 90);
            // g.FillEllipse(b, rect);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
        }
        public float px = 0, py, t = 0f,m=0f;
       public Queue myQ = new Queue();
       public Queue myQ1 = new Queue();
        private void timer1_Tick(object sender, EventArgs e)
        {
            
           Graphics g = this.CreateGraphics();
            //Graphics g = this.CreateGraphics();
           Pen pen = new Pen(Color.FromArgb(255, 50, 100, 50), 5);
            
            //// px=5.4f * t;
            ////  px=500F;

            //py=0.5f*9.8f*t*t/1000/1000*4000;
            //g.DrawEllipse(pen,px, py, 10.0f, 10.0f);
            t += 10f;
            //if ( py > 2000)
            //{
            //    px +=20;
            //    py = 0;
            //    t = 0;
            //}
            //if (px > 2000)
            //{
            //    px = 0;
                
            //}
            // Creates and initializes a new Queue.
             this.Refresh();
            float amp = 250f;
            float period = 500;
            
            if(myQ.Count<=100)
            {
                myQ.Enqueue(amp * Math.Sin(2 * Math.PI / period * t));
               
                
            }else 
            {
                myQ.Enqueue(amp * Math.Sin(2 * Math.PI / period * t));
            myQ.Dequeue();
           
            }
            if (myQ1.Count <=100)
            {
                myQ1.Enqueue(amp * Math.Cos(2 * Math.PI / period * t));


            }
            else
            {
                myQ1.Enqueue(amp * Math.Cos(2 * Math.PI / period * t));
                myQ1.Dequeue();

            }
           //Array a1=Array.CreateInstance(typeof(string),myQ.Count);
           object[] a2 = myQ.ToArray();
           object[] a3 = myQ1.ToArray();
           // myQ.CopyTo(a1, 0);
           //for ( int l = 0; l < a1.Length; l++)
           //{
           //    g.DrawEllipse(pen, m, float.Parse(a1.GetValue(l).ToString()), 10.0f, 10.0f);
           //    m += 10;
           
           //}
           m = 0;
           for (int l = 0; l < a2.Length; l++)
           {
               g.DrawEllipse(pen, m, float.Parse(a2.GetValue(l).ToString())+500, 10.0f, 10.0f);
              // g.DrawEllipse(pen, m, float.Parse(a3.GetValue(l).ToString()) + 500, 10.0f, 10.0f);
               m += 10;

           }
            
           // this.Refresh();
           // m = 0; 
            
        }

        private void sin_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }
    }
}
