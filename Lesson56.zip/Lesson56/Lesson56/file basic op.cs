﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//使用file类，需要添加该命名空间

namespace Lesson56
{
    public partial class file_basic_op : Form
    {
        public file_basic_op()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog a = new OpenFileDialog();//a是自己定义的变量名
            if (a.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("File length:"+File.Open(a.FileName,FileMode.Open).Length.ToString()+"bytes","tips^$^");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog a = new OpenFileDialog();//这个按键的函数可以和上一个函数用一个变量
            if (a.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("file substring:"+a.FileName.Substring(a.FileName.LastIndexOf(".")+1,a.FileName.Length-a.FileName.LastIndexOf(".")-1),"tips^*^");
            }
        }

        private void file_basic_op_Load(object sender, EventArgs e)
        {
            tabControl1.TabPages[0].Text = "文件大小";
            tabControl1.TabPages[1].Text = "文件后缀";
            tabControl1.TabPages[2].Text = "create time";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog a = new OpenFileDialog();
            if (a.ShowDialog() == DialogResult.OK)
            {
                FileInfo b = new FileInfo(a.FileName);
                MessageBox.Show("create time:"+b.CreationTime.ToString(),"tips^*^");
            }
        }
    }
}
