﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq.Expressions;

namespace Lesson56
{
    public partial class lamd1 : Form
    {
        public lamd1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            await a();
            textBox1.Text+="\r\nlamda success^6^\r\n";
            pictureBox1.Show();
            await a();
            pictureBox2.Show();
            await a();
            pictureBox3.Show();
            await a();
            pictureBox4.Show();
            await a();
            pictureBox5.Show();
            await a();



        }
        async Task a()//a is a user-defined function name
        {
        await Task.Delay(1000);
        }

        private void lamd1_Load(object sender, EventArgs e)
        {
           // await a();
           // textBox1.Text += "\r\nlamda success^6^\r\n";
            pictureBox1.Hide();
           // await a();
            pictureBox2.Hide();
          //  await a();
            pictureBox3.Hide();
           // await a();
            pictureBox4.Hide();
          //  await a();
            pictureBox5.Hide();
           // await a();
        }
        delegate int sq(int j);//sq is an user-defined name
        private void button2_Click(object sender, EventArgs e)
        {
            sq ms = k => k * k;
            int b = ms(3);
            MessageBox.Show("the square of 3 is "+  b.ToString());
        }
    }
}
