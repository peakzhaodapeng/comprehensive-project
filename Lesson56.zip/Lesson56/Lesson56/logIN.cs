﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson56
{
    public partial class logIN : Form
    {
        public logIN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (idtextBox1.Text == "peak" && pwtextBox2.Text == "123")
                {
                    Lesson56.统计客户数量 frm3 = new 统计客户数量();
                    frm3.Show();
                }
                else
                {
                    MessageBox.Show("wrong input,please inout again");
                }
            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void logIN_Load(object sender, EventArgs e)
        {

        }
    }
}
