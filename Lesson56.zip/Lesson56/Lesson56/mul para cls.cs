﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Lesson56
{
    public partial class mul_para_cls : Form
    {
        public mul_para_cls()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            threaddemo td = new threaddemo();
            td.a = 1;
            td.b = 2;
            Thread tho = new Thread(new ThreadStart(td.function));
            tho.Start();
        }
        class threaddemo
        {
            mul_para_cls mc = new mul_para_cls();
            public int a, b;
            public void function()
            {
                mc.textBox1.Text +=a.ToString();
                mc.textBox1 .Text+= b.ToString();
                
                //MessageBox.Show(a.ToString());
               // MessageBox.Show(b.ToString());
            }
        }
    }
}
