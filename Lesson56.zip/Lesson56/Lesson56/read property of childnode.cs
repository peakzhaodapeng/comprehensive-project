﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;

namespace Lesson56
{
    public partial class read_property_of_childnode : Form
    {
        public read_property_of_childnode()
        {
            InitializeComponent();
        }

        private void read_property_of_childnode_Load(object sender, EventArgs e)
        {
        
                XmlDocument doc = new XmlDocument();
                doc.LoadXml("<book ISBN='1-861001-57-5'>" +
                            "<title>Pride And Prejudice</title>" +
                            "<price>19.95</price>" +
                            "</book>");

                XmlNode root = doc.FirstChild;

                //Display the contents of the child nodes.
                if (root.HasChildNodes)
                {
                  for (int i=0; i<root.ChildNodes.Count; i++)
                  {
                      textBox1.Text += root.ChildNodes[i].InnerText + "\r\n";
                    //Console.WriteLine(root.ChildNodes[i].InnerText);
                  }
                }
          }
      }
}
