﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson56
{
    public partial class sp_event : Form
    {
         string data;
        public sp_event()
        {
            InitializeComponent();
        }
        private void sp_event_Load(object sender, EventArgs e)
        {
            serialPort1.PortName = "COM5";
            serialPort1.BaudRate = 9600;
            serialPort1.Open();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            string output=textBox2.Text;
            if (output == "")
            {
                MessageBox.Show("can not send nothing");
            
           }
            serialPort1.Write(output);

        }

       
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void sp_datareiceive(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            data = serialPort1.ReadExisting();
            this.Invoke(new EventHandler(display));
        }
        private void display(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + data;

        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            Close();
        }
        private void form_close(object sender, FormClosedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }
    }
}
