﻿namespace Lesson56
{
    partial class stream_module_w_r_xml_file1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.write_xml = new System.Windows.Forms.Button();
            this.read_xml = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // write_xml
            // 
            this.write_xml.Location = new System.Drawing.Point(45, 21);
            this.write_xml.Name = "write_xml";
            this.write_xml.Size = new System.Drawing.Size(75, 23);
            this.write_xml.TabIndex = 0;
            this.write_xml.Text = "write";
            this.write_xml.UseVisualStyleBackColor = true;
            this.write_xml.Click += new System.EventHandler(this.button1_Click);
            // 
            // read_xml
            // 
            this.read_xml.Location = new System.Drawing.Point(45, 61);
            this.read_xml.Name = "read_xml";
            this.read_xml.Size = new System.Drawing.Size(75, 23);
            this.read_xml.TabIndex = 1;
            this.read_xml.Text = "read";
            this.read_xml.UseVisualStyleBackColor = true;
            this.read_xml.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(138, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(311, 554);
            this.textBox1.TabIndex = 2;
            // 
            // stream_module_w_r_xml_file1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 599);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.read_xml);
            this.Controls.Add(this.write_xml);
            this.Name = "stream_module_w_r_xml_file1";
            this.Text = "stream_module_w_r_xml_file1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button write_xml;
        private System.Windows.Forms.Button read_xml;
        private System.Windows.Forms.TextBox textBox1;
    }
}