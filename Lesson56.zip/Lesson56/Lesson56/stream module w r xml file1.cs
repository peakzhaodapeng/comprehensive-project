﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
//using System.Collections.Generic;

namespace Lesson56
{
    public partial class stream_module_w_r_xml_file1 : Form
    {
        public stream_module_w_r_xml_file1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //XmlReaderSettings settings = new XmlReaderSettings();
            //settings.IgnoreComments = true;
            //settings.IgnoreWhitespace = true;

            //XmlReader reader = XmlReader.Create("Customer2.xml", settings);
            //List<CustomerInfo> lists = new List<CustomerInfo>();

            //CustomerInfo cust = null;



            //while (reader.Read())
            //{
            //    if (reader.NodeType == XmlNodeType.Element)
            //    {
            //        switch (reader.Name)
            //        {
            //            case "row":
            //                cust = new CustomerInfo();
            //                if (reader.HasAttributes)
            //                {
            //                    cust.AppId = reader.GetAttribute("AppID");
            //                    cust.Version = reader.GetAttribute("Version");
            //                }
            //                break;

            //            case "CustomerID":
            //                cust.CustomerID = reader.ReadString();
            //                break;

            //            case "CompanyName":
            //                cust.CompanyName = reader.ReadString();
            //                break;
            //            case "ContactName":

            //                cust.ContactName = reader.ReadString();
            //                break;
            //            case "ContactTitle":

            //                cust.ContactTitle = reader.ReadString();
            //                break;

            //            case "Address":

            //                cust.Address = reader.ReadString();
            //                break;


            //            case "City":
            //                cust.City = reader.ReadString();
            //                break;


            //            case "PostalCode":
            //                cust.PostalCode = reader.ReadString();
            //                break;
            //            case "Country":
            //                cust.Country = reader.ReadString();
            //                break;
            //            case "Phone":
            //                cust.Phone = reader.ReadString();
            //                break;
            //            case "Fax":
            //                cust.Fax = reader.ReadString();
            //                lists.Add(cust);
            //                break;
            //            default:
            //                break;

            //        }
            //    }

            //}

        }

        private void button1_Click(object sender, EventArgs e)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.NewLineOnAttributes = false;
            XmlWriter writer = XmlWriter.Create("d:\\oder info.xml", settings);//文件保存在了C:\Users\Administrator\Desktop\CSharpStudy\Lesson56\Lesson56\bin\Debug
            writer.WriteStartDocument(true);
            writer.WriteStartElement("orders");
            writer.WriteComment("order info");
            writer.WriteStartElement("order");
            writer.WriteAttributeString("orderID","001");
            writer.WriteAttributeString("orderDate", "2010-01-01");
            writer.WriteElementString("num", "5");
            writer.WriteElementString("price", "6.0");
            writer.WriteEndElement();
            //no 2
            writer.WriteStartElement("order");
            writer.WriteAttributeString("orderID", "002");
            writer.WriteAttributeString("orderDate", "2010-01-02");
            writer.WriteElementString("num", "4");
            writer.WriteElementString("price", "8.0");
            writer.WriteEndElement();
            //no 3
            writer.WriteRaw("\r\n <oder oderID='003' oderDate='2012-02-03'>" +//both &quat; and ' are ok
                "\r\n<num>7</num>"+
            "\r\n<price>9.0</price>"+
            "\r\n</order>\r\n");
            writer.WriteFullEndElement();
            writer.Flush();
            writer.Close();
        }
    }
}
