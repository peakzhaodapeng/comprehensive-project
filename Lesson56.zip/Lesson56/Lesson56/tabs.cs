﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson56
{
    public partial class tabs : Form
    {
        public tabs()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabs_Load(object sender, EventArgs e)
        {
            tabControl1.Appearance = TabAppearance.Normal;
            tabControl1.TabPages[0].Text = "研发部人员名单";
            tabControl1.TabPages[1].Text = "生产部";
            tabControl1.TabPages[2].Text = "管理部";
            //TabPage tp1 = new TabPage("sale");
            //tabControl1.TabPages.Add(tp1);
            comboBox2.Items.Clear();
            comboBox2.Items.Add("song");
            comboBox2.Items.Add("guanyu");
            this.comboBox2.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = AutoCompleteSource.ListItems;
            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                listBox1.Items.Add(textBox1.Text);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(listBox1.SelectedItem);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text=listBox1.Items.Count.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            comboBox2.Items.Add(textBox3.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //comboBox2.Items.Remove(comboBox2.SelectedIndex);
            comboBox2.Items.Remove(comboBox2.SelectedItem);
        }
    }
}
