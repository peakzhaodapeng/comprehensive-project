﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Lesson56
{
    public partial class th_para : Form
    {
        public th_para()
        {
            InitializeComponent();
        }

        private void th_para_Load(object sender, EventArgs e)
        {
            Thread tho = new Thread(new ParameterizedThreadStart(meth));//tho 是线程的名称，mesh是方法名
            tho.Start("this is a para");

        }
        private static void meth(object o)
        {
            MessageBox.Show("传入的参数是:"+o.ToString());
        }
    }
}
