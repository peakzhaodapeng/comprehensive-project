﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Lesson56
{
    public partial class thread_no_param : Form
    {
        public thread_no_param()
        {
            InitializeComponent();
        }

        private void thread_no_param_Load(object sender, EventArgs e)
        {
            Thread thexam = new Thread(new ThreadStart(ma));
            thexam.Start();
        }
        private static void ma()
        {
            MessageBox.Show("this is a thread");
        }
       
    }
   
    
}
