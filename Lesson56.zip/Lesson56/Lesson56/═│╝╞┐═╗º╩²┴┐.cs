﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson56
{
    public partial class 统计客户数量 : Form
    {
        public 统计客户数量()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text=Convert.ToString(int.Parse(textBox1.Text)+1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(int.Parse(textBox1.Text)-1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBox1.Text);
            //Math.Sin(Math.PI);
            
        }
    }
}
