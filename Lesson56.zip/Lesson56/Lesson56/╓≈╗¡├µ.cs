﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Lesson19窗体的基本属性
{
    public partial class Form1 : Form
    {
        public int x = 1;

        public Form1()
        {
            InitializeComponent();
            //MessageBox.Show("queding"); 
        }
        

        //private void button1_Click(object sender, EventArgs e)
        //{
          
        //}

        private void 菜单项1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 子菜单1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("仅显示消息！");
        }

        private void 带标题的消息框ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("消息内容","消息标题");
        }

        private void 带标题和按钮的消息框ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("消息内容","按键有多种表现形式", MessageBoxButtons.YesNoCancel);
        }

        private void 带标题图标和按钮的消息框ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("消息内容","消息标题",MessageBoxButtons.RetryCancel,MessageBoxIcon.Warning);
        }

        private void 控件属性ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson19窗体的基本属性.form2 frm2 = new form2();
            frm2.MdiParent = this;
            frm2.Show();

        }

        private void 控件的应用ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.统计客户数量 frm3 = new Lesson56.统计客户数量();
            frm3.MdiParent = this;
            frm3.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        //private void textBox1_TextChanged(object sender, EventArgs e)
        //{
            
            
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Opacity = Convert.ToDouble(this.textBox1.Text);
                //this.Opacity =1.0d;
            }
            catch (Exception f)
            {
                MessageBox.Show(f.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this.label1.Text);
        }

        private void 输入账号和密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.logIN login = new Lesson56.logIN();
            login.MdiParent = this;
            login.Show();
        }

        private void 富文本框控件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.rtf rtf_form = new Lesson56.rtf();
            rtf_form.MdiParent = this;
            rtf_form.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void 选择类控件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.choosecomponent chooseFrm = new Lesson56.choosecomponent();
            chooseFrm.MdiParent = this;
            chooseFrm.Show();
        }

        private void 常用电阻值ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.resisterValue RV = new Lesson56.resisterValue();
            RV.MdiParent = this;
            RV.Show();
        }

        private void 选项卡应用ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.tabs tbs = new Lesson56.tabs();
            tbs.MdiParent = this;
            tbs.Show();
        }

        private void serialport查询方式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.SP_query  QRY= new Lesson56.SP_query();
            QRY.MdiParent = this;
            QRY.Show();

        }

        private void serialport事件方式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.sp_event sp_e = new Lesson56.sp_event();
            sp_e.MdiParent = this;
            sp_e.Show();
        }

        private void 不带参数ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.thread_no_param nopa = new Lesson56.thread_no_param();
            nopa.MdiParent = this;
            nopa.Show();
        }

        private void 带参数线程ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.th_para tp = new Lesson56.th_para();
            tp.MdiParent = this;
            tp.Show();
        }

        private void 带多个参数线程使用类ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.mul_para_cls mc = new Lesson56.mul_para_cls();
            mc.MdiParent = this;
            mc.Show();
        }

        private void 插入指定路径图片ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.insert_pic_path pathpic = new Lesson56.insert_pic_path();
            pathpic.MdiParent = this;
            pathpic.Show();
        }

        private void 文件基本操作ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.file_basic_op fileop = new Lesson56.file_basic_op();
            fileop.MdiParent = this;
            fileop.Show();
        }

        private void testReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.test_report1 tp = new Lesson56.test_report1();
            tp.MdiParent = this;
            tp.Show();
        }

        private void lamda表达式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.lamd1 ld = new Lesson56.lamd1();
            ld.MdiParent = this;
            ld.Show();
        }

        private void 委托ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.del1 d = new Lesson56.del1();
            d.MdiParent = this;
            d.Show();
        }

        private void 顶级菜单项2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void fontSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.font_size_table ft = new Lesson56.font_size_table();
            ft.MdiParent = this;
            ft.Show();
        }

        private void c学习网址ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.cslearn cl = new Lesson56.cslearn();
            cl.MdiParent = this;
            cl.Show();
        }

        private void 新能源客车ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.bus_size_inner1 bs = new Lesson56.bus_size_inner1();
            bs.MdiParent = this;
            bs.Show();
        }

        private void createXmlFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.create_xml_file1 create_xml=new Lesson56.create_xml_file1();
            create_xml.MdiParent=this;
            create_xml.Show();
        }

        private void 流处理模型读写xmlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.stream_module_w_r_xml_file1 stream = new Lesson56.stream_module_w_r_xml_file1();
            stream.MdiParent = this;
            stream.Show();
        }

        private void 读取子节点属性ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.read_property_of_childnode r_child_vl = new Lesson56.read_property_of_childnode();
            r_child_vl.MdiParent = this;
            r_child_vl.Show();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void 振动传感器ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.vibration_sensor1 vs = new Lesson56.vibration_sensor1();
            vs.MdiParent = this;
            vs.Show();
        }

        private void drawACircleAndFillBlackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.drawACircle drawCicle = new Lesson56.drawACircle();
            drawCicle.MdiParent = this;
            drawCicle.Show();
        }

        private void 绘制一个带坐标和网格的曲线ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.curve_with_net curveNet = new Lesson56.curve_with_net();
            curveNet.MdiParent = this;
            curveNet.Show();
        }

        private void 读取CSV文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lesson56.read_csv rCsv = new Lesson56.read_csv();
            rCsv.MdiParent = this;
            rCsv.Show();

        }

        private void 顶级菜单项1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        //private void 菜单项1ToolStripMenuItem_Click(object sender, EventArgs e)
        //{

        //}

        //private void 打开子菜单ToolStripMenuItem_Click(object sender, EventArgs e)
        //{

        //}
        

    }
}
