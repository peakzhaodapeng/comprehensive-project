﻿namespace Lesson19窗体的基本属性
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.顶级菜单项1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单项1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.子菜单1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.带标题的消息框ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.带标题和按钮的消息框ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.带标题图标和按钮的消息框ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单项2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.控件属性ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.控件的应用ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.文本类控件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.输入账号和密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.富文本框控件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选择类控件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.常用电阻值ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选项卡应用ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.串口通信ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serialport查询方式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serialport事件方式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.不带参数ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.带参数线程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.带多个参数线程使用类ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.带多参数线程使用结构ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.word操作ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.插入指定路径图片ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.文件基本操作ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lamda表达式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.委托ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createXmlFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.流处理模型读写xmlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.读取子节点属性ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageProcessingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drawACircleAndFillBlackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.绘制一个带坐标和网格的曲线ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.操作CSVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.读取CSV文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.顶级菜单项2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.c学习网址ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客车内部尺寸ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客车ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客车尺寸 = new System.Windows.Forms.ToolStripMenuItem();
            this.振动传感器ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.顶级菜单项1ToolStripMenuItem,
            this.顶级菜单项2ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1904, 25);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 顶级菜单项1ToolStripMenuItem
            // 
            this.顶级菜单项1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单项1ToolStripMenuItem,
            this.菜单项2ToolStripMenuItem,
            this.文本类控件ToolStripMenuItem,
            this.选择类控件ToolStripMenuItem,
            this.常用电阻值ToolStripMenuItem,
            this.选项卡应用ToolStripMenuItem,
            this.串口通信ToolStripMenuItem,
            this.chartToolStripMenuItem,
            this.comToolStripMenuItem,
            this.threadToolStripMenuItem,
            this.word操作ToolStripMenuItem,
            this.文件基本操作ToolStripMenuItem,
            this.lamda表达式ToolStripMenuItem,
            this.委托ToolStripMenuItem,
            this.xMLToolStripMenuItem,
            this.imageProcessingToolStripMenuItem,
            this.操作CSVToolStripMenuItem});
            this.顶级菜单项1ToolStripMenuItem.Name = "顶级菜单项1ToolStripMenuItem";
            this.顶级菜单项1ToolStripMenuItem.Size = new System.Drawing.Size(80, 21);
            this.顶级菜单项1ToolStripMenuItem.Text = "见好记思齐";
            this.顶级菜单项1ToolStripMenuItem.Click += new System.EventHandler(this.顶级菜单项1ToolStripMenuItem_Click);
            // 
            // 菜单项1ToolStripMenuItem
            // 
            this.菜单项1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.子菜单1ToolStripMenuItem,
            this.带标题的消息框ToolStripMenuItem,
            this.带标题和按钮的消息框ToolStripMenuItem,
            this.带标题图标和按钮的消息框ToolStripMenuItem});
            this.菜单项1ToolStripMenuItem.Name = "菜单项1ToolStripMenuItem";
            this.菜单项1ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.菜单项1ToolStripMenuItem.Text = "常用的输入输出方法";
            this.菜单项1ToolStripMenuItem.Click += new System.EventHandler(this.菜单项1ToolStripMenuItem_Click);
            // 
            // 子菜单1ToolStripMenuItem
            // 
            this.子菜单1ToolStripMenuItem.Name = "子菜单1ToolStripMenuItem";
            this.子菜单1ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.子菜单1ToolStripMenuItem.Text = "最简单的消息框";
            this.子菜单1ToolStripMenuItem.Click += new System.EventHandler(this.子菜单1ToolStripMenuItem_Click);
            // 
            // 带标题的消息框ToolStripMenuItem
            // 
            this.带标题的消息框ToolStripMenuItem.Name = "带标题的消息框ToolStripMenuItem";
            this.带标题的消息框ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.带标题的消息框ToolStripMenuItem.Text = "带标题的消息框";
            this.带标题的消息框ToolStripMenuItem.Click += new System.EventHandler(this.带标题的消息框ToolStripMenuItem_Click);
            // 
            // 带标题和按钮的消息框ToolStripMenuItem
            // 
            this.带标题和按钮的消息框ToolStripMenuItem.Name = "带标题和按钮的消息框ToolStripMenuItem";
            this.带标题和按钮的消息框ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.带标题和按钮的消息框ToolStripMenuItem.Text = "带标题和按钮的消息框";
            this.带标题和按钮的消息框ToolStripMenuItem.Click += new System.EventHandler(this.带标题和按钮的消息框ToolStripMenuItem_Click);
            // 
            // 带标题图标和按钮的消息框ToolStripMenuItem
            // 
            this.带标题图标和按钮的消息框ToolStripMenuItem.Name = "带标题图标和按钮的消息框ToolStripMenuItem";
            this.带标题图标和按钮的消息框ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.带标题图标和按钮的消息框ToolStripMenuItem.Text = "带标题、图标和按钮的消息框";
            this.带标题图标和按钮的消息框ToolStripMenuItem.Click += new System.EventHandler(this.带标题图标和按钮的消息框ToolStripMenuItem_Click);
            // 
            // 菜单项2ToolStripMenuItem
            // 
            this.菜单项2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.控件属性ToolStripMenuItem,
            this.控件的应用ToolStripMenuItem});
            this.菜单项2ToolStripMenuItem.Name = "菜单项2ToolStripMenuItem";
            this.菜单项2ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.菜单项2ToolStripMenuItem.Text = "按钮类控件";
            // 
            // 控件属性ToolStripMenuItem
            // 
            this.控件属性ToolStripMenuItem.Name = "控件属性ToolStripMenuItem";
            this.控件属性ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.控件属性ToolStripMenuItem.Text = "控件属性";
            this.控件属性ToolStripMenuItem.Click += new System.EventHandler(this.控件属性ToolStripMenuItem_Click);
            // 
            // 控件的应用ToolStripMenuItem
            // 
            this.控件的应用ToolStripMenuItem.Name = "控件的应用ToolStripMenuItem";
            this.控件的应用ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.控件的应用ToolStripMenuItem.Text = "控件的应用";
            this.控件的应用ToolStripMenuItem.Click += new System.EventHandler(this.控件的应用ToolStripMenuItem_Click);
            // 
            // 文本类控件ToolStripMenuItem
            // 
            this.文本类控件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.输入账号和密码ToolStripMenuItem,
            this.富文本框控件ToolStripMenuItem});
            this.文本类控件ToolStripMenuItem.Name = "文本类控件ToolStripMenuItem";
            this.文本类控件ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.文本类控件ToolStripMenuItem.Text = "文本类控件";
            // 
            // 输入账号和密码ToolStripMenuItem
            // 
            this.输入账号和密码ToolStripMenuItem.Name = "输入账号和密码ToolStripMenuItem";
            this.输入账号和密码ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.输入账号和密码ToolStripMenuItem.Text = "输入账号和密码";
            this.输入账号和密码ToolStripMenuItem.Click += new System.EventHandler(this.输入账号和密码ToolStripMenuItem_Click);
            // 
            // 富文本框控件ToolStripMenuItem
            // 
            this.富文本框控件ToolStripMenuItem.Name = "富文本框控件ToolStripMenuItem";
            this.富文本框控件ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.富文本框控件ToolStripMenuItem.Text = "富文本框控件";
            this.富文本框控件ToolStripMenuItem.Click += new System.EventHandler(this.富文本框控件ToolStripMenuItem_Click);
            // 
            // 选择类控件ToolStripMenuItem
            // 
            this.选择类控件ToolStripMenuItem.Name = "选择类控件ToolStripMenuItem";
            this.选择类控件ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.选择类控件ToolStripMenuItem.Text = "选择类控件";
            this.选择类控件ToolStripMenuItem.Click += new System.EventHandler(this.选择类控件ToolStripMenuItem_Click);
            // 
            // 常用电阻值ToolStripMenuItem
            // 
            this.常用电阻值ToolStripMenuItem.Name = "常用电阻值ToolStripMenuItem";
            this.常用电阻值ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.常用电阻值ToolStripMenuItem.Text = "常用电阻值";
            this.常用电阻值ToolStripMenuItem.Click += new System.EventHandler(this.常用电阻值ToolStripMenuItem_Click);
            // 
            // 选项卡应用ToolStripMenuItem
            // 
            this.选项卡应用ToolStripMenuItem.Name = "选项卡应用ToolStripMenuItem";
            this.选项卡应用ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.选项卡应用ToolStripMenuItem.Text = "选项卡应用";
            this.选项卡应用ToolStripMenuItem.Click += new System.EventHandler(this.选项卡应用ToolStripMenuItem_Click);
            // 
            // 串口通信ToolStripMenuItem
            // 
            this.串口通信ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.serialport查询方式ToolStripMenuItem,
            this.serialport事件方式ToolStripMenuItem});
            this.串口通信ToolStripMenuItem.Name = "串口通信ToolStripMenuItem";
            this.串口通信ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.串口通信ToolStripMenuItem.Text = "串口通信";
            // 
            // serialport查询方式ToolStripMenuItem
            // 
            this.serialport查询方式ToolStripMenuItem.Name = "serialport查询方式ToolStripMenuItem";
            this.serialport查询方式ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.serialport查询方式ToolStripMenuItem.Text = "serialport查询方式";
            this.serialport查询方式ToolStripMenuItem.Click += new System.EventHandler(this.serialport查询方式ToolStripMenuItem_Click);
            // 
            // serialport事件方式ToolStripMenuItem
            // 
            this.serialport事件方式ToolStripMenuItem.Name = "serialport事件方式ToolStripMenuItem";
            this.serialport事件方式ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.serialport事件方式ToolStripMenuItem.Text = "serialport事件方式";
            this.serialport事件方式ToolStripMenuItem.Click += new System.EventHandler(this.serialport事件方式ToolStripMenuItem_Click);
            // 
            // chartToolStripMenuItem
            // 
            this.chartToolStripMenuItem.Name = "chartToolStripMenuItem";
            this.chartToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.chartToolStripMenuItem.Text = "chart";
            // 
            // comToolStripMenuItem
            // 
            this.comToolStripMenuItem.Name = "comToolStripMenuItem";
            this.comToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.comToolStripMenuItem.Text = "com";
            // 
            // threadToolStripMenuItem
            // 
            this.threadToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.不带参数ToolStripMenuItem,
            this.带参数线程ToolStripMenuItem,
            this.带多个参数线程使用类ToolStripMenuItem,
            this.带多参数线程使用结构ToolStripMenuItem});
            this.threadToolStripMenuItem.Name = "threadToolStripMenuItem";
            this.threadToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.threadToolStripMenuItem.Text = "thread";
            // 
            // 不带参数ToolStripMenuItem
            // 
            this.不带参数ToolStripMenuItem.Name = "不带参数ToolStripMenuItem";
            this.不带参数ToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.不带参数ToolStripMenuItem.Text = "不带参数";
            this.不带参数ToolStripMenuItem.Click += new System.EventHandler(this.不带参数ToolStripMenuItem_Click);
            // 
            // 带参数线程ToolStripMenuItem
            // 
            this.带参数线程ToolStripMenuItem.Name = "带参数线程ToolStripMenuItem";
            this.带参数线程ToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.带参数线程ToolStripMenuItem.Text = "带参数线程";
            this.带参数线程ToolStripMenuItem.Click += new System.EventHandler(this.带参数线程ToolStripMenuItem_Click);
            // 
            // 带多个参数线程使用类ToolStripMenuItem
            // 
            this.带多个参数线程使用类ToolStripMenuItem.Name = "带多个参数线程使用类ToolStripMenuItem";
            this.带多个参数线程使用类ToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.带多个参数线程使用类ToolStripMenuItem.Text = "带多个参数线程（使用类）";
            this.带多个参数线程使用类ToolStripMenuItem.Click += new System.EventHandler(this.带多个参数线程使用类ToolStripMenuItem_Click);
            // 
            // 带多参数线程使用结构ToolStripMenuItem
            // 
            this.带多参数线程使用结构ToolStripMenuItem.Name = "带多参数线程使用结构ToolStripMenuItem";
            this.带多参数线程使用结构ToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.带多参数线程使用结构ToolStripMenuItem.Text = "带多参数线程（使用结构）";
            // 
            // word操作ToolStripMenuItem
            // 
            this.word操作ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.插入指定路径图片ToolStripMenuItem,
            this.testReportToolStripMenuItem});
            this.word操作ToolStripMenuItem.Name = "word操作ToolStripMenuItem";
            this.word操作ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.word操作ToolStripMenuItem.Text = "word操作";
            // 
            // 插入指定路径图片ToolStripMenuItem
            // 
            this.插入指定路径图片ToolStripMenuItem.Name = "插入指定路径图片ToolStripMenuItem";
            this.插入指定路径图片ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.插入指定路径图片ToolStripMenuItem.Text = "create word doc";
            this.插入指定路径图片ToolStripMenuItem.Click += new System.EventHandler(this.插入指定路径图片ToolStripMenuItem_Click);
            // 
            // testReportToolStripMenuItem
            // 
            this.testReportToolStripMenuItem.Name = "testReportToolStripMenuItem";
            this.testReportToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.testReportToolStripMenuItem.Text = "test report";
            this.testReportToolStripMenuItem.Click += new System.EventHandler(this.testReportToolStripMenuItem_Click);
            // 
            // 文件基本操作ToolStripMenuItem
            // 
            this.文件基本操作ToolStripMenuItem.Name = "文件基本操作ToolStripMenuItem";
            this.文件基本操作ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.文件基本操作ToolStripMenuItem.Text = "文件基本操作";
            this.文件基本操作ToolStripMenuItem.Click += new System.EventHandler(this.文件基本操作ToolStripMenuItem_Click);
            // 
            // lamda表达式ToolStripMenuItem
            // 
            this.lamda表达式ToolStripMenuItem.Name = "lamda表达式ToolStripMenuItem";
            this.lamda表达式ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.lamda表达式ToolStripMenuItem.Text = "lamda表达式";
            this.lamda表达式ToolStripMenuItem.Click += new System.EventHandler(this.lamda表达式ToolStripMenuItem_Click);
            // 
            // 委托ToolStripMenuItem
            // 
            this.委托ToolStripMenuItem.Name = "委托ToolStripMenuItem";
            this.委托ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.委托ToolStripMenuItem.Text = "委托";
            this.委托ToolStripMenuItem.Click += new System.EventHandler(this.委托ToolStripMenuItem_Click);
            // 
            // xMLToolStripMenuItem
            // 
            this.xMLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createXmlFileToolStripMenuItem,
            this.流处理模型读写xmlToolStripMenuItem,
            this.读取子节点属性ToolStripMenuItem});
            this.xMLToolStripMenuItem.Name = "xMLToolStripMenuItem";
            this.xMLToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.xMLToolStripMenuItem.Text = "XML";
            // 
            // createXmlFileToolStripMenuItem
            // 
            this.createXmlFileToolStripMenuItem.Name = "createXmlFileToolStripMenuItem";
            this.createXmlFileToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.createXmlFileToolStripMenuItem.Text = "Create xml file";
            this.createXmlFileToolStripMenuItem.Click += new System.EventHandler(this.createXmlFileToolStripMenuItem_Click);
            // 
            // 流处理模型读写xmlToolStripMenuItem
            // 
            this.流处理模型读写xmlToolStripMenuItem.Name = "流处理模型读写xmlToolStripMenuItem";
            this.流处理模型读写xmlToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.流处理模型读写xmlToolStripMenuItem.Text = "流处理模型读写xml";
            this.流处理模型读写xmlToolStripMenuItem.Click += new System.EventHandler(this.流处理模型读写xmlToolStripMenuItem_Click);
            // 
            // 读取子节点属性ToolStripMenuItem
            // 
            this.读取子节点属性ToolStripMenuItem.Name = "读取子节点属性ToolStripMenuItem";
            this.读取子节点属性ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.读取子节点属性ToolStripMenuItem.Text = "读取子节点属性";
            this.读取子节点属性ToolStripMenuItem.Click += new System.EventHandler(this.读取子节点属性ToolStripMenuItem_Click);
            // 
            // imageProcessingToolStripMenuItem
            // 
            this.imageProcessingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.drawACircleAndFillBlackToolStripMenuItem,
            this.绘制一个带坐标和网格的曲线ToolStripMenuItem});
            this.imageProcessingToolStripMenuItem.Name = "imageProcessingToolStripMenuItem";
            this.imageProcessingToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.imageProcessingToolStripMenuItem.Text = "image processing";
            // 
            // drawACircleAndFillBlackToolStripMenuItem
            // 
            this.drawACircleAndFillBlackToolStripMenuItem.Name = "drawACircleAndFillBlackToolStripMenuItem";
            this.drawACircleAndFillBlackToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.drawACircleAndFillBlackToolStripMenuItem.Text = "draw a circle and fill black";
            this.drawACircleAndFillBlackToolStripMenuItem.Click += new System.EventHandler(this.drawACircleAndFillBlackToolStripMenuItem_Click);
            // 
            // 绘制一个带坐标和网格的曲线ToolStripMenuItem
            // 
            this.绘制一个带坐标和网格的曲线ToolStripMenuItem.Name = "绘制一个带坐标和网格的曲线ToolStripMenuItem";
            this.绘制一个带坐标和网格的曲线ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.绘制一个带坐标和网格的曲线ToolStripMenuItem.Text = "绘制一个带坐标和网格的曲线";
            this.绘制一个带坐标和网格的曲线ToolStripMenuItem.Click += new System.EventHandler(this.绘制一个带坐标和网格的曲线ToolStripMenuItem_Click);
            // 
            // 操作CSVToolStripMenuItem
            // 
            this.操作CSVToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.读取CSV文件ToolStripMenuItem});
            this.操作CSVToolStripMenuItem.Name = "操作CSVToolStripMenuItem";
            this.操作CSVToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.操作CSVToolStripMenuItem.Text = "操作CSV";
            // 
            // 读取CSV文件ToolStripMenuItem
            // 
            this.读取CSV文件ToolStripMenuItem.Name = "读取CSV文件ToolStripMenuItem";
            this.读取CSV文件ToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.读取CSV文件ToolStripMenuItem.Text = "读取CSV文件";
            this.读取CSV文件ToolStripMenuItem.Click += new System.EventHandler(this.读取CSV文件ToolStripMenuItem_Click);
            // 
            // 顶级菜单项2ToolStripMenuItem
            // 
            this.顶级菜单项2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.c学习网址ToolStripMenuItem,
            this.fontSizeToolStripMenuItem,
            this.客车内部尺寸ToolStripMenuItem,
            this.振动传感器ToolStripMenuItem});
            this.顶级菜单项2ToolStripMenuItem.Name = "顶级菜单项2ToolStripMenuItem";
            this.顶级菜单项2ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.顶级菜单项2ToolStripMenuItem.Text = "工作利器";
            this.顶级菜单项2ToolStripMenuItem.Click += new System.EventHandler(this.顶级菜单项2ToolStripMenuItem_Click);
            // 
            // c学习网址ToolStripMenuItem
            // 
            this.c学习网址ToolStripMenuItem.Name = "c学习网址ToolStripMenuItem";
            this.c学习网址ToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.c学习网址ToolStripMenuItem.Text = "c#学习网址";
            this.c学习网址ToolStripMenuItem.Click += new System.EventHandler(this.c学习网址ToolStripMenuItem_Click);
            // 
            // fontSizeToolStripMenuItem
            // 
            this.fontSizeToolStripMenuItem.Name = "fontSizeToolStripMenuItem";
            this.fontSizeToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.fontSizeToolStripMenuItem.Text = "font size";
            this.fontSizeToolStripMenuItem.Click += new System.EventHandler(this.fontSizeToolStripMenuItem_Click);
            // 
            // 客车内部尺寸ToolStripMenuItem
            // 
            this.客车内部尺寸ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.客车ToolStripMenuItem});
            this.客车内部尺寸ToolStripMenuItem.Name = "客车内部尺寸ToolStripMenuItem";
            this.客车内部尺寸ToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.客车内部尺寸ToolStripMenuItem.Text = "汽车知识";
            // 
            // 客车ToolStripMenuItem
            // 
            this.客车ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.客车尺寸});
            this.客车ToolStripMenuItem.Name = "客车ToolStripMenuItem";
            this.客车ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.客车ToolStripMenuItem.Text = "客车";
            // 
            // 客车尺寸
            // 
            this.客车尺寸.Name = "客车尺寸";
            this.客车尺寸.Size = new System.Drawing.Size(124, 22);
            this.客车尺寸.Text = "客车尺寸";
            this.客车尺寸.Click += new System.EventHandler(this.新能源客车ToolStripMenuItem_Click);
            // 
            // 振动传感器ToolStripMenuItem
            // 
            this.振动传感器ToolStripMenuItem.Name = "振动传感器ToolStripMenuItem";
            this.振动传感器ToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.振动传感器ToolStripMenuItem.Text = "振动传感器";
            this.振动传感器ToolStripMenuItem.Click += new System.EventHandler(this.振动传感器ToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(33, 50);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "输入一个值，改变窗体的透明度";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(156, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "change opacity";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(1566, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(326, 95);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(1239, 34);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1904, 1042);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.No;
            this.HelpButton = true;
            this.IsMdiContainer = true;
            this.Location = new System.Drawing.Point(0, 1080);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1920, 1080);
            this.MinimumSize = new System.Drawing.Size(800, 1038);
            this.Name = "Form1";
            this.Opacity = 0.95D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 顶级菜单项1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单项1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单项2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 顶级菜单项2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 子菜单1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 带标题的消息框ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 带标题和按钮的消息框ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 带标题图标和按钮的消息框ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 控件属性ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 控件的应用ToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripMenuItem 文本类控件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 输入账号和密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 富文本框控件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 选择类控件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 常用电阻值ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 选项卡应用ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 串口通信ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serialport查询方式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serialport事件方式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 不带参数ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 带参数线程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 带多个参数线程使用类ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 带多参数线程使用结构ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem word操作ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 插入指定路径图片ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 文件基本操作ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lamda表达式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 委托ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem c学习网址ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客车内部尺寸ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客车ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客车尺寸;
        private System.Windows.Forms.ToolStripMenuItem xMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createXmlFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 流处理模型读写xmlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 读取子节点属性ToolStripMenuItem;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.ToolStripMenuItem 振动传感器ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imageProcessingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drawACircleAndFillBlackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 绘制一个带坐标和网格的曲线ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 操作CSVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 读取CSV文件ToolStripMenuItem;
    }
}

